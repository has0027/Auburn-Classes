//
//  ViewController.swift
//  Assignment1b_ThreeButtons
//
//  Created by Haden Stuart on 6/4/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageOnScreen: UIImageView!
    
    
    @IBAction func ButtonAuburn(_ sender: UIButton) {
        ImageOnScreen.image = UIImage(named: "AU Logo")
    }
    
    @IBAction func ButtonSEC(_ sender: UIButton) {
        ImageOnScreen.image = UIImage(named: "SEC Logo")
    }
    
    @IBAction func ButtonBama(_ sender: UIButton) {
        ImageOnScreen.image = UIImage(named: "Bama Logo")
    }
    
    
    

    
}

