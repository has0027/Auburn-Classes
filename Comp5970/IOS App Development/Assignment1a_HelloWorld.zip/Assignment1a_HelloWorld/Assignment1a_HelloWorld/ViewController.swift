//
//  ViewController.swift
//  Assignment1a_HelloWorld
//
//  Created by Haden Stuart on 5/30/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

