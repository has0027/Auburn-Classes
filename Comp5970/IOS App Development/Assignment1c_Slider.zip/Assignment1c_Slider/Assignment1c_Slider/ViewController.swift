//
//  ViewController.swift
//  Assignment1c_Slider
//
//  Created by Haden Stuart on 6/9/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

// Outlets
    @IBOutlet weak var AuburnImageView: UIImageView!
    
    @IBOutlet weak var AlabamaImageView: UIImageView!
    
    @IBOutlet weak var MainSlider: UISlider!
    
// Actions
    
    @IBAction func SliderValueChanged(_ sender: UISlider) {
        
        AuburnImageView.alpha = CGFloat(1 - sender.value)
        
        AlabamaImageView.alpha = CGFloat(sender.value)
    
    }
}
