//
//  ViewController.swift
//  Assignment2a_LoanCalculator
//
//  Created by Haden Stuart on 6/19/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var LoanIn: UITextField!
    @IBOutlet weak var PaymentsIn: UITextField!
    @IBOutlet weak var InterestRateIn: UITextField!
    @IBOutlet weak var ResultOut: UITextField!
    
    
    @IBAction func CalculateButton(_ sender: UIButton) {
        // Get interest rate into Double type
        /* Different cases:
            monthly = split into pieces, set string to double, then calculate
            annual = set string to double
        */
        let interestRateInTmp: String = InterestRateIn.text!
        let interestRate: Double
        
        if (interestRateInTmp.contains("/")) {
            let interestRateArray = interestRateInTmp.components(separatedBy: "/")
            let newArray = interestRateArray.map {Double($0)!}
            interestRate = newArray[0] / newArray[1]
        }
        else {
            interestRate = Double(InterestRateIn.text!)!
        }
        
        // Covert all input values to correct types
        let loan: Int = Int(LoanIn.text!)!
        let payments: Int = Int(PaymentsIn.text!)!
        
        // Calculate using calculator
        let calculation: Double = loanCalculator(loan, payments, interestRate)
                
        // Output result
        ResultOut.text = String(format: "%.2f", calculation)
    }
    
    
    // Calculate loan
    func loanCalculator(_ loanIn: Int, _ paymentsIn: Int, _ interestRateIn: Double)->Double {
        var result: Double
        let loan = Double(loanIn)
        let payments = Double(paymentsIn)
        let interestRate = Double(interestRateIn / 100)
       
        // Monthly payments
        if (interestRateIn < 1) {
            let eq1 = loan * interestRate
            let eq2 = pow((1 + interestRate), payments)
            result = eq1 * (eq2 / (eq2 - 1))
        }
        // Annual payments
        else {
            let eq1 = loan * interestRate
            let eq2 = pow((1 + interestRate), payments/12)
            result = eq1 * (eq2 / (eq2 - 1))
        }
        return result
    }
}

