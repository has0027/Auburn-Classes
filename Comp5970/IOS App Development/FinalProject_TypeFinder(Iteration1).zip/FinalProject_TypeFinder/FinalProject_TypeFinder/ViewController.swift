//
//  ViewController.swift
//  FinalProject_TypeFinder
//
//  Created by Haden Stuart on 7/6/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // Top of app outlets
    @IBOutlet weak var TypeLabel: UILabel!
    @IBOutlet weak var Strong1: UIImageView!
    @IBOutlet weak var Strong2: UIImageView!
    @IBOutlet weak var Strong3: UIImageView!
    @IBOutlet weak var Strong4: UIImageView!
    @IBOutlet weak var Strong5: UIImageView!
    @IBOutlet weak var Weak1: UIImageView!
    @IBOutlet weak var Weak2: UIImageView!
    @IBOutlet weak var Weak3: UIImageView!
    @IBOutlet weak var Weak4: UIImageView!
    @IBOutlet weak var Weak5: UIImageView!
    
    
    // Button outlets
    @IBOutlet weak var NormalLook: UIButton!
    @IBOutlet weak var GrassLook: UIButton!
    @IBOutlet weak var FireLook: UIButton!
    @IBOutlet weak var WaterLook: UIButton!
    @IBOutlet weak var FightingLook: UIButton!
    @IBOutlet weak var FlyingLook: UIButton!
    @IBOutlet weak var PoisonLook: UIButton!
    @IBOutlet weak var GroundLook: UIButton!
    @IBOutlet weak var RockLook: UIButton!
    @IBOutlet weak var BugLook: UIButton!
    @IBOutlet weak var GhostLook: UIButton!
    @IBOutlet weak var ElectricLook: UIButton!
    @IBOutlet weak var PsychicLook: UIButton!
    @IBOutlet weak var IceLook: UIButton!
    @IBOutlet weak var DragonLook: UIButton!
    @IBOutlet weak var DarkLook: UIButton!
    @IBOutlet weak var SteelLook: UIButton!
    @IBOutlet weak var FairyLook: UIButton!
    
    // Set icons on startup
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the icon size in each button
        NormalLook.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        GrassLook.imageEdgeInsets = UIEdgeInsets(top: 14, left: 12, bottom: 12, right: 15)
        FireLook.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        WaterLook.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        FightingLook.imageEdgeInsets = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        FlyingLook.imageEdgeInsets = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        PoisonLook.imageEdgeInsets = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        GroundLook.imageEdgeInsets = UIEdgeInsets(top: 10, left: 13, bottom: 15, right: 14)
        RockLook.imageEdgeInsets = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        BugLook.imageEdgeInsets = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        GhostLook.imageEdgeInsets = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        ElectricLook.imageEdgeInsets = UIEdgeInsets(top: 12, left: 11, bottom: 11, right: 12)
        PsychicLook.imageEdgeInsets = UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)
        IceLook.imageEdgeInsets = UIEdgeInsets(top: 11, left: 11, bottom: 11, right: 11)
        DragonLook.imageEdgeInsets = UIEdgeInsets(top: 11, left: 10, bottom: 13, right: 11)
        DarkLook.imageEdgeInsets = UIEdgeInsets(top: 13, left: 13, bottom: 13, right: 13)
        SteelLook.imageEdgeInsets = UIEdgeInsets(top: 11, left: 11, bottom: 11, right: 11)
        FairyLook.imageEdgeInsets = UIEdgeInsets(top: 11, left: 11, bottom: 11, right: 11)
    }

    @IBAction func NormalButton(_ sender: UIButton) {
        TypeLabel.text = "Normal"
        Strong1.image = nil
        Strong2.image = nil
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatFighting.png")
        Weak2.image = nil
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func GrassButton(_ sender: UIButton) {
        TypeLabel.text = "Grass"
        Strong1.image = UIImage(named: "StatGround.png")
        Strong2.image = UIImage(named: "StatRock.png")
        Strong3.image = UIImage(named: "StatWater.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatBug.png")
        Weak2.image = UIImage(named: "StatFire.png")
        Weak3.image = UIImage(named: "StatFlying.png")
        Weak4.image = UIImage(named: "StatIce.png")
        Weak5.image = UIImage(named: "StatPoison.png")
    }
    
    @IBAction func FireButton(_ sender: UIButton) {
        TypeLabel.text = "Fire"
        Strong1.image = UIImage(named: "StatBug.png")
        Strong2.image = UIImage(named: "StatGrass.png")
        Strong3.image = UIImage(named: "StatIce.png")
        Strong4.image = UIImage(named: "StatSteel.png")
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatGround.png")
        Weak2.image = UIImage(named: "StatRock.png")
        Weak3.image = UIImage(named: "StatWater.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func WaterButton(_ sender: UIButton) {
        TypeLabel.text = "Water"
        Strong1.image = UIImage(named: "StatFire.png")
        Strong2.image = UIImage(named: "StatGround.png")
        Strong3.image = UIImage(named: "StatRock.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatElectric.png")
        Weak2.image = UIImage(named: "StatGrass.png")
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func FightingButton(_ sender: UIButton) {
        TypeLabel.text = "Fighting"
        Strong1.image = UIImage(named: "StatDark.png")
        Strong2.image = UIImage(named: "StatIce.png")
        Strong3.image = UIImage(named: "StatNormal.png")
        Strong4.image = UIImage(named: "StatRock.png")
        Strong5.image = UIImage(named: "StatSteel.png")
        Weak1.image = UIImage(named: "StatFairy.png")
        Weak2.image = UIImage(named: "StatFlying.png")
        Weak3.image = UIImage(named: "StatPsychic.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func FlyingButton(_ sender: UIButton) {
        TypeLabel.text = "Flying"
        Strong1.image = UIImage(named: "StatBug.png")
        Strong2.image = UIImage(named: "StatGrass.png")
        Strong3.image = UIImage(named: "StatFighting.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatElectric.png")
        Weak2.image = UIImage(named: "StatIce.png")
        Weak3.image = UIImage(named: "StatRock.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func PoisonButton(_ sender: UIButton) {
        TypeLabel.text = "Poison"
        Strong1.image = UIImage(named: "StatFairy.png")
        Strong2.image = UIImage(named: "StatGrass.png")
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatGround.png")
        Weak2.image = UIImage(named: "StatPsychic.png")
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func GroundButton(_ sender: UIButton) {
        TypeLabel.text = "Ground"
        Strong1.image = UIImage(named: "StatElectric.png")
        Strong2.image = UIImage(named: "StatFire.png")
        Strong3.image = UIImage(named: "StatPoison.png")
        Strong4.image = UIImage(named: "StatRock.png")
        Strong5.image = UIImage(named: "StatSteel.png")
        Weak1.image = UIImage(named: "StatGrass.png")
        Weak2.image = UIImage(named: "StatIce.png")
        Weak3.image = UIImage(named: "StatWater.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func RockButton(_ sender: UIButton) {
        TypeLabel.text = "Rock"
        Strong1.image = UIImage(named: "StatBug.png")
        Strong2.image = UIImage(named: "StatFire.png")
        Strong3.image = UIImage(named: "StatFlying.png")
        Strong4.image = UIImage(named: "StatIce.png")
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatFighting.png")
        Weak2.image = UIImage(named: "StatGrass.png")
        Weak3.image = UIImage(named: "StatGround.png")
        Weak4.image = UIImage(named: "StatSteel.png")
        Weak5.image = UIImage(named: "StatWater.png")
    }
    
    @IBAction func BugButton(_ sender: UIButton) {
        TypeLabel.text = "Bug"
        Strong1.image = UIImage(named: "StatDark.png")
        Strong2.image = UIImage(named: "StatGrass.png")
        Strong3.image = UIImage(named: "StatPsychic.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatFire.png")
        Weak2.image = UIImage(named: "StatFlying.png")
        Weak3.image = UIImage(named: "StatRock.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func GhostButton(_ sender: UIButton) {
        TypeLabel.text = "Ghost"
        Strong1.image = UIImage(named: "StatGhost.png")
        Strong2.image = UIImage(named: "StatPsychic.png")
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatDark.png")
        Weak2.image = UIImage(named: "StatGhost.png")
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func ElectricButton(_ sender: UIButton) {
        TypeLabel.text = "Electric"
        Strong1.image = UIImage(named: "StatFlying.png")
        Strong2.image = UIImage(named: "StatWater.png")
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatGround.png")
        Weak2.image = nil
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func PsychicButton(_ sender: UIButton) {
        TypeLabel.text = "Psychic"
        Strong1.image = UIImage(named: "StatFighting.png")
        Strong2.image = UIImage(named: "StatPoison.png")
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatBug.png")
        Weak2.image = UIImage(named: "StatDark.png")
        Weak3.image = UIImage(named: "StatGhost.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func IceButton(_ sender: UIButton) {
        TypeLabel.text = "Ice"
        Strong1.image = UIImage(named: "StatDragon.png")
        Strong2.image = UIImage(named: "StatFlying.png")
        Strong3.image = UIImage(named: "StatGrass.png")
        Strong4.image = UIImage(named: "StatGround.png")
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatFighting.png")
        Weak2.image = UIImage(named: "StatFire.png")
        Weak3.image = UIImage(named: "StatRock.png")
        Weak4.image = UIImage(named: "StatSteel.png")
        Weak5.image = nil
    }
    
    @IBAction func DragonButton(_ sender: UIButton) {
        TypeLabel.text = "Dragon"
        Strong1.image = UIImage(named: "StatDragon.png")
        Strong2.image = nil
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatDragon.png")
        Weak2.image = UIImage(named: "StatFairy.png")
        Weak3.image = UIImage(named: "StatIce.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func DarkButton(_ sender: UIButton) {
        TypeLabel.text = "Dark"
        Strong1.image = UIImage(named: "StatGhost.png")
        Strong2.image = UIImage(named: "StatPsychic.png")
        Strong3.image = nil
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatBug.png")
        Weak2.image = UIImage(named: "StatFairy.png")
        Weak3.image = UIImage(named: "StatFighting.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func SteelButton(_ sender: UIButton) {
        TypeLabel.text = "Steel"
        Strong1.image = UIImage(named: "StatFairy.png")
        Strong2.image = UIImage(named: "StatIce.png")
        Strong3.image = UIImage(named: "StatRock.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatFighting.png")
        Weak2.image = UIImage(named: "StatFire.png")
        Weak3.image = UIImage(named: "StatGround.png")
        Weak4.image = nil
        Weak5.image = nil
    }
    
    @IBAction func FairyButton(_ sender: UIButton) {
        TypeLabel.text = "Fairy"
        Strong1.image = UIImage(named: "StatDark.png")
        Strong2.image = UIImage(named: "StatDragon.png")
        Strong3.image = UIImage(named: "StatFighting.png")
        Strong4.image = nil
        Strong5.image = nil
        Weak1.image = UIImage(named: "StatPoison.png")
        Weak2.image = UIImage(named: "StatSteel.png")
        Weak3.image = nil
        Weak4.image = nil
        Weak5.image = nil
    }
    
    
    
    
    
    
    
}

