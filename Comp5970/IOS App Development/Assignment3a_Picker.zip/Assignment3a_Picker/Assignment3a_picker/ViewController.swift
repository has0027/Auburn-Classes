//
//  ViewController.swift
//  Assignment3a_picker
//
//  Created by Haden Stuart on 7/12/20.
//  Copyright © 2020 Haden Stuart. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var viewPicker: UIPickerView!
    @IBOutlet weak var viewTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    private var pickerText = ["Thing One", "Thing Two", "Thing Three"]
    

    @IBAction func selectButton(_ sender: UIButton) {
        let row = viewPicker.selectedRow(inComponent: 0)
        let selected = pickerText[row]
        
        let alert = UIAlertController(
            title: selected,
            message: "This is your current selection",
            preferredStyle: .alert)
        let action = UIAlertAction(
            title: "Understood",
            style: .default,
            handler: nil)
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func replaceButton(_ sender: Any) {
        let row = viewPicker.selectedRow(inComponent: 0)
        pickerText[row] = viewTextField.text!
        viewPicker.reloadComponent(0)
    }
    
    @IBAction func insertButton(_ sender: UIButton) {
        let row = viewPicker.selectedRow(inComponent: 0)
        
        pickerText.insert(viewTextField.text!, at: row+1)
        viewPicker.reloadComponent(0)
        viewPicker.selectRow(row+1, inComponent: 0, animated: true)
    }
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerText.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerText[row]
    }

}

