/*
This program acts as the UDP server for project 1.

@author Haden Stuart
@version 7/21/20
 */

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.Arrays;
import java.nio.charset.StandardCharsets;


public class ServerUDP {
    public static void main(String[] args) throws Exception {
        // Create datagram socket
        DatagramSocket serverSocket = new DatagramSocket(80);

        // Create blank header, receive and send arrays
        Header requestHeader = null;
        byte[] receiveData = new byte[256];
        byte[] sendData;

        while (true) {
            // Receive datagram
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);

            // Get packet data
            String packetDataIn = new String(receivePacket.getData());

            // Check if correct request, then send header accordingly
            String[] request = packetDataIn.split(" ");
            String openFile = null;

            if (request.length != 3) {
                String errorContentLength = "None";
                String errorContentType = "None";
                requestHeader = new Header(errorContentType, errorContentLength, 400);
            }
            else {
                // Check for correct GET method and if file exists
                File requestedFile = new File(request[1]);
                if (request[0].toUpperCase().equals("GET") && requestedFile.exists()) {
                    requestHeader = new Header(contentTypeFinder(request[1]), contentLengthFinder(request[1]), 200);
                    openFile = readFile(request[1]);
                }
                else if (!request[0].toUpperCase().equals("GET") && !requestedFile.exists()) {
                    requestHeader = new Header(contentTypeFinder(request[1]), contentLengthFinder(request[1]), 400);
                }
                else if (request[0].toUpperCase().equals("GET") && !requestedFile.exists()) {
                    requestHeader = new Header(contentTypeFinder(request[1]), contentLengthFinder(request[1]), 404);
                }
                else if (!request[0].toUpperCase().equals("GET") && requestedFile.exists()) {
                    requestHeader = new Header(contentTypeFinder(request[1]), contentLengthFinder(request[1]), 405);
                }
            }

            // Transport info
            InetAddress IPAddress = receivePacket.getAddress();
            int destPort = receivePacket.getPort();

            // Combine request header with data
            assert requestHeader != null;
            String requestHeaderFinalString = requestHeader.requestHeaderString();
            String combinedData = requestHeaderFinalString;
            if (openFile != null)
                combinedData = requestHeaderFinalString + openFile;
            byte[] combinedDataBytes = combinedData.getBytes();

            // Populate datagram and send data by using exactly data.length/248 number of equal sized packets (saving 8bytes for header)
            int start = 0;
            int end = 248;
            short checksum;
            DatagramPacket sendPacket;
            byte[] packetToSend;

            for (int i = 0; i < (double)combinedDataBytes.length/248; i++) {
                // Make sure endpoint doesn't go over length
                if (end > combinedDataBytes.length)
                    end = combinedDataBytes.length;

                // Copy each set of 248 bytes into new array
                byte[] byteData = Arrays.copyOfRange(combinedDataBytes, start, end);

                // Create packet header for current packet
                checksum = generateChecksum(byteData);
                int temp = byteData.length + 8;
                packetToSend = new byte[temp];

                packetToSend[0] = ((byte) 80);                // Source port byte1
                packetToSend[1] = ((byte) 0);                 // Source port byte2
                packetToSend[2] = ((byte) 80);                // Destination port byte1
                packetToSend[3] = ((byte) 0);                 // Destination port byte2
                packetToSend[4] = ((byte) (temp >>> 8));      // Content length byte1 (using bitwise shift right)
                packetToSend[5] = ((byte) temp);              // Content length byte2
                packetToSend[6] = ((byte) (checksum >>> 8));  // Checksum byte1 (using bitwise shift right)
                packetToSend[7] = ((byte) checksum);          // Checksum byte2

                // Print into server console
                System.out.println(new String(byteData));

                // Merge header with data and send packet
                System.arraycopy(byteData, 0, packetToSend, 8, byteData.length);

                sendData = packetToSend;
                sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, destPort);
                serverSocket.send(sendPacket);

                // Shift to next packet content in array
                start = end;
                end = end + 248;
            }

            // Send end of file byte
            sendData = new byte[1];
            sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, destPort);
            serverSocket.send(sendPacket);
        }
    }

    // Read file
    private static String readFile(String filename) {
        String result = "";
        byte[] numBytes;

        if (filename == null)
            return result;

        try {
            numBytes = Files.readAllBytes(Paths.get(filename));
        } catch (IOException e) {
            return result;
        }

        result = new String(numBytes, StandardCharsets.UTF_8);
        return result;
    }

    // Find length of content in file
    public static String contentLengthFinder(String filename) {
        String fileLength = "000";
        byte[] numBytes;

        if (filename == null)
            return fileLength;

        try {
            numBytes = Files.readAllBytes(Paths.get(filename));
            fileLength = Integer.toString(numBytes.length);
        } catch (IOException e) {
            return fileLength;
        }
        return fileLength;
    }

    // Find type of content in file
    public static String contentTypeFinder(String filename) {
        String fileType = "";
        if (filename.endsWith(".txt"))
            fileType = "text/plain";
        else if (filename.endsWith(".html") || filename.endsWith(".htm"))
            fileType = "text/html";
        else if (filename.endsWith(".mjs") || filename.endsWith(".js"))
            fileType = "text/javascript";
        else if (filename.endsWith(".css"))
            fileType = "text/css";
        else if (filename.endsWith("."))
            fileType = "text/html";

        return fileType;
    }

    // Generate checksum
    public static short generateChecksum(byte[] packetDataIn) {
        short checksumResult = 0;
        for (int num : packetDataIn)
            checksumResult += num;
        return checksumResult;
    }

}
