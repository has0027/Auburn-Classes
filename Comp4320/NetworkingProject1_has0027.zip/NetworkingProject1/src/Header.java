public class Header {
    private final String contentType;
    private final String contentLength;
    private final int statusCode;

    public Header(String contentTypeIn, String contentLengthIn, int statusCodeIn) {
        contentType = contentTypeIn;
        contentLength = contentLengthIn;
        statusCode = statusCodeIn;
    }

    public String statusCodeMessage(int codeIn) {
        return switch (codeIn) {
            case 200 -> "Document Follows";
            case 400 -> "Bad Request";
            case 404 -> "File Not Found";
            case 405 -> "Method Not Allowed";
            case 500 -> "Internal Server Error";
            case 503 -> "Service Is Down";
            default -> "Bad Status Code";
        };
    }

    public String requestHeaderString() {
        return "HTTP/1.0 "
                + statusCode + " "
                + statusCodeMessage(statusCode) + "\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + contentLength + "\r\n"
                + "\r\n";
    }


}
