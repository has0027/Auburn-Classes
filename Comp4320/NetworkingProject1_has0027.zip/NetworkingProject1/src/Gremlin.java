/*
This program takes a packet and determines whether to pass
it on or to corrupt the bytes in the packet.

@author Haden Stuart
@version 7/21/20
 */

import java.net.*;
import java.util.Random;

// If the probability of damaging a packet is .3, then three out of every ten packets will be damaged.
// If the packet is to be damaged, the probability of changing one byte is .5,
// the probability of changing two bytes is .3, and the probability of changing 3 bytes is .2
public class Gremlin {
    DatagramPacket packet;
    byte[] randomBytes = new byte[256];
    int damagedBytes = 0;
    int damageProb;

    public Gremlin(DatagramPacket packetIn, double damageProbIn) {
        damageProb = (int)(damageProbIn * 100);
        packet = packetIn;
    }

    public boolean randomNumberSpinner() {
        int rand = (int)(Math.random() * 100);
        return rand <= damageProb;
    }

    public byte[] damageData() {
        Random random = new Random();
        byte[] packetBytes = packet.getData();
        random.nextBytes(randomBytes);
        int tempRand;

        for (int i = 8; i < packetBytes.length; i++) {
            tempRand = random.nextInt(100);

            if (damagedBytes == 0 && tempRand <= 50) {
                packetBytes[i] = (byte)tempRand;
                damagedBytes = 1;
            }
            else if (damagedBytes == 1 && tempRand <= 30) {
                packetBytes[i] = (byte)tempRand;
                damagedBytes = 2;
            }
            else if (damagedBytes == 2 && tempRand <= 20) {
                packetBytes[i] = (byte)tempRand;
                damagedBytes = 3;
            }
            else {
                break;
            }
        }

        return packetBytes;
    }

}
