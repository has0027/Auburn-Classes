/*
This program acts as the UDP client for project 1.

@author Haden Stuart
@version 7/21/20
 */

import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.Scanner;


public class ClientUDP {
    public static void main(String[] args) throws Exception {
        // Create client socket
        DatagramSocket clientSocket = new DatagramSocket();

        Scanner scanner = new Scanner(System.in);
        byte[] sendData;
        byte[] receiveData = new byte[256];
        byte[] damagedData;
        byte[] nonDamagedData;
        byte[] tempCopy;
        int currentChecksum;
        int startingChecksum;
        double damageProb;
        Gremlin gremlin;
        InetAddress IPAddress = InetAddress.getByName("192.168.1.2");
        int port = 80;

        // Get HTTP input and set as sendData
        System.out.print("Enter HTTP Request: ");
        String requestIn = scanner.nextLine();
        sendData = requestIn.getBytes();

        // Get Gremlin damage probability
        System.out.print("Enter Gremlin Damage Probability: ");
        String probabilityIn = scanner.nextLine();
        damageProb = Double.parseDouble(probabilityIn);
        while (damageProb > 1.00) {
            System.out.println("Error: Gremlin probability must be below 1.00!");
            System.out.print("Enter Gremlin Damage Probability: ");
            probabilityIn = scanner.nextLine();
            damageProb = Double.parseDouble(probabilityIn);
        }


        // Create datagram and send to server
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
        clientSocket.send(sendPacket);
        System.out.println("Sending message: " + requestIn);

        // Create receiving datagram from server
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        // Create 5 second timeout to prevent program from looping infinitely if not connecting
        clientSocket.setSoTimeout(5000);
        try {
            clientSocket.receive(receivePacket);
        } catch (SocketTimeoutException e) {
            System.out.println("Error: connection timeout");
            clientSocket.close();
        }

        // Receive each packet, send to Gremlin, print contents, combine data to previous data
        if (!clientSocket.isClosed()) {
            // Receive file header
            String responseData;
            System.out.println("Receiving message: ");

            // Run Gremlin for first packet
            tempCopy = receivePacket.getData();
            startingChecksum = ((tempCopy[6] & 0xFF) << 8) + (tempCopy[7] & 0xFF);
            String firstPacketString = new String(tempCopy);
            String[] responseHeader = firstPacketString.split("[ ]");

            gremlin = new Gremlin(receivePacket, damageProb);
            if (gremlin.randomNumberSpinner()) {
                damagedData = gremlin.damageData();
                tempCopy = Arrays.copyOfRange(damagedData, 8, damagedData.length);
            } else {
                nonDamagedData = receivePacket.getData();
                tempCopy = Arrays.copyOfRange(nonDamagedData, 8, nonDamagedData.length);
            }
            currentChecksum = generateChecksum(tempCopy);

            // Error detection
            if (currentChecksum == startingChecksum) {
                responseData = new String(tempCopy);
                System.out.println(responseData);
            }
            else {
                System.out.println("Packet #1 Contains an Error!");
                responseData = "Packet #1 Contains an Error!\n";
            }

            StringBuilder combinedData = new StringBuilder();
            combinedData.append(responseData);
            int count = 2;

            if (responseHeader[1].equals("200")) {
                while (true) {
                    // Receive packet
                    receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    clientSocket.receive(receivePacket);
                    tempCopy = receivePacket.getData();

                    // Break loop when end of file byte found
                    if (tempCopy[0] == 0) {
                        break;
                    }

                    // Get checksum before sending data to gremlin
                    startingChecksum = ((tempCopy[6] & 0xFF) << 8) + (tempCopy[7] & 0xFF);

                    // Send to Gremlin and print
                    gremlin = new Gremlin(receivePacket, damageProb);
                    if (gremlin.randomNumberSpinner()) {
                        damagedData = gremlin.damageData();
                        tempCopy = Arrays.copyOfRange(damagedData, 8, damagedData.length);
                    } else {
                        nonDamagedData = receivePacket.getData();
                        tempCopy = Arrays.copyOfRange(nonDamagedData, 8, nonDamagedData.length);
                    }

                    // Check for null values in array
                    byte[] checkArray = tempCopy;
                    for (int i = 0; i < checkArray.length; i++) {
                        if (checkArray[i] == 0) {
                            tempCopy = Arrays.copyOfRange(checkArray, 0, i);
                            break;
                        }
                    }

                    // Error detection
                    currentChecksum = generateChecksum(tempCopy);
                    if (currentChecksum == startingChecksum) {
                        responseData = new String(tempCopy);
                        System.out.println(responseData);
                    }
                    else {
                        System.out.println("Packet #" + count + " Contains an Error!");
                        responseData = "\nPacket #" + count + " Contains an Error!\n";
                    }

                    // Shift count to next packet number and reset receiveData
                    count++;
                    receiveData = new byte[256];

                    // Combine data
                    combinedData.append(responseData);
                }

                // Write combined packet data to file
                Writer writer;
                writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("NewResults.txt")));
                writer.write(combinedData.toString());
                writer.close();
            }
            clientSocket.close();
        }
    }

    // Generate checksum
    public static short generateChecksum(byte[] packetDataIn) {
        short checksumResult = 0;
        for (int num : packetDataIn)
            checksumResult += num;
        return checksumResult;
    }
}
